﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Summitworks_EventManager.Models;

namespace Summitworks_EventManager.ViewModels
{
    public class HomeDetailsViewModel
    {
        public Event Event { get; set; }
        public string PageTitle { get; set; }
    }
}
