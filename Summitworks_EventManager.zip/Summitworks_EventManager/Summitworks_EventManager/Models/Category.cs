﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Summitworks_EventManager.Models
{
    public enum Category
    {
        Wedding,
        Conference,
        Trade_Show,
        Seminars,
        Executive_Meeting,
        Company_Party,
        Product_Launch

    }
}
